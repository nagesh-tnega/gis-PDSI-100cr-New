<?php
// define('HOST', 'localhost');
// define('PORT', '5432');
// define('USER', 'postgres');
// define('PASS', 'PG@tnega');
//define('PASS', 'postgres');
// define('DB_NAME', 'c100');

//Staging Geo Server Credentials.
// define('GSURL', 'http://125.18.51.83:8080/geoserver');
// define('WORKSPACE', 'c100');
// define('DATASTORE', 'c100_store');
// define('GSPASS', 'GSP4tnega');
// define('GSUSER', 'admin');

//Development Geo Server Credentials.
/*define('GSURL', 'http://localhost:8081/geoserver');
define('WORKSPACE', 'c100');
define('DATASTORE', 'c100_store');
define('GSPASS', 'geoserver');
define('GSUSER', 'admin');*/

// define('ROOTDIR', dirname(__DIR__));

// define('DOMAIN','http://125.18.51.83/major_infra/');
//define('DOMAIN','http://localhost/major_infra/');


define('HOST', 'localhost');
define('PORT', '5432');
define('USER', 'postgres');
define('PASS', 'PG@tnega');
define('DB_NAME', 'c100');
define('GSURL', 'http://125.18.51.83:8080/geoserver');
define('WORKSPACE', 'c100');
define('DATASTORE', 'c100_store');
define('GSPASS', 'GSP4tnega');
define('GSUSER', 'admin');

define('ROOTDIR', dirname(__DIR__));

define('DOMAIN','');

?>